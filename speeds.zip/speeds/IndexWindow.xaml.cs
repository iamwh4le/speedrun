﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace speeds
{

    public partial class IndexWindow : Window
    {
        private GetUser_Result _user;
        public IndexWindow(GetUser_Result user)
        {
            InitializeComponent();
            _user = user;
            GetTable();

            if (user.RoleName == "Администратор")
            {
                CreateBtn.Visibility = Visibility.Visible;
                RemoveBtn.Visibility = Visibility.Visible;
                AdminPanel.Visibility = Visibility.Visible;
            }
            else if(user.RoleName == "Менеджер")
            {
                RemoveBtn.Visibility = Visibility.Visible;
            }
            else if (user.RoleName == "Клиент")
            {
                CreateBtn.Visibility = Visibility.Visible;
                RemoveBtn.Visibility = Visibility.Visible;
            }
        }

        public void GetTable()
        {
            List<GetOrders_Result> ordersShow = new List<GetOrders_Result>();
            speedrunEntities entities = new speedrunEntities();
            if (_user.RoleName == "Администратор")
            {
                List<GetOrders_Result> orders = new List<GetOrders_Result>();
                orders = entities.GetOrders().ToList();
                OrdersGrid.ItemsSource = orders;
            }
            else if (_user.RoleName == "Менеджер")
            {
                foreach (var order in entities.GetOrders())
                {
                    if (order.managerID == _user.id || order.managerID == 7)
                    {
                        ordersShow.Add(order);
                    }
                }
                OrdersGrid.ItemsSource = ordersShow;
            }
            else if (_user.RoleName == "Клиент")
            {
                foreach (var order in entities.GetOrders())
                {
                    if (order.clientID == _user.id)
                    {
                        ordersShow.Add(order);
                    }
                }
                OrdersGrid.ItemsSource = ordersShow;
            }
            else if (_user.RoleName == "Сотрудник")
            {
                foreach (var order in entities.GetOrders())
                {
                    if (order.employeesID == _user.id)
                    {
                        ordersShow.Add(order);
                    }
                }
                OrdersGrid.ItemsSource = ordersShow;
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            GetTable();
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы хотите завершить работу программы?", "Закрытие программы", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                AuthWindow authWnd = new AuthWindow();
                Application.Current.MainWindow = authWnd;
                authWnd.Show();
                this.Close();
            }
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {

            EditOrderWindow editOrderWnd = new EditOrderWindow("creating", new GetOrders_Result());
            editOrderWnd.ShowDialog();
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            GetOrders_Result row = (GetOrders_Result)OrdersGrid.SelectedItems[0];
            if (row != null)
            {
                EditOrderWindow editOrderWnd = new EditOrderWindow("editing", row);
                editOrderWnd.ShowDialog();
            }
        }
    }
}
