﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace speeds
{
    public partial class AuthWindow : Window
    {
        public AuthWindow()
        {
            InitializeComponent();
        }

        private void SignInBtn_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text;
            login = login.Replace(" ", "");

            if (String.IsNullOrEmpty(login))
            {
                MessageBox.Show("Поле 'Логин' заполнено некорректно", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (String.IsNullOrEmpty(PasswdBox.Password))
            {
                MessageBox.Show("Поле 'Пароль' заполнено некорректно", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            speedrunEntities entities = new speedrunEntities();
            GetUser_Result user = new GetUser_Result();

            try
            {
                user = entities.GetUser(login, PasswdBox.Password).First();
                if (user != null)
                {
                    IndexWindow indexWnd = new IndexWindow(user);
                    Application.Current.MainWindow = indexWnd;
                    indexWnd.Show();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неверный логин или пароль", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SignUpWndBtn_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow regWnd = new RegistrationWindow();
            regWnd.ShowDialog();
        }

    }
}
