﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace speeds
{
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void SignUpBtn_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text, email = EmailBox.Text, name = NameBox.Text, surname = SurnameBox.Text, lastname = LastnameBox.Text, phoneNum = PhoneNumBox.Text;
            login = login.Replace(" ", "");
            email = email.Replace(" ", "");
            name = name.Replace(" ", "");
            surname = surname.Replace(" ", "");
            lastname = lastname.Replace(" ", "");
            phoneNum = phoneNum.Replace(" ", "");

            if (String.IsNullOrEmpty(login))
            {
                MessageBox.Show("Поле 'Логин' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (PasswdBox.Password.Length < 6)
            {
                MessageBox.Show("Поле 'Пароль' должно содержать от 6 символов", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (PasswdBox.Password != PasswdRepeatBox.Password)
            {
                MessageBox.Show("Поле 'Повторить пароль' не совпадает с полем 'Пароль'", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (String.IsNullOrEmpty(email))
            {
                MessageBox.Show("Поле 'Email' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (String.IsNullOrEmpty(surname))
            {
                MessageBox.Show("Поле 'Фамилия' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (String.IsNullOrEmpty(name))
            {
                MessageBox.Show("Поле 'Имя' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (String.IsNullOrEmpty(lastname))
            {
                MessageBox.Show("Поле 'Отчество' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (!String.IsNullOrEmpty(phoneNum))
            {
                if(!int.TryParse(phoneNum, out int num))
                {
                    MessageBox.Show("Поле 'Номер телефона' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Поле 'Номер телефона' заполнено некорректно", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            speedrunEntities entities = new speedrunEntities();

            try
            {
                var user = entities.GetUser(login, PasswdRepeatBox.Password).First();
                if (user != null)
                {
                    MessageBox.Show("Пользователь с данным логином уже существует", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch
            {
                try
                {
                    int result = entities.CreateUser(login, PasswdRepeatBox.Password, email, name, surname, lastname, phoneNum, 4);
                    if (result == 1)
                    {
                        MessageBox.Show("Пользователь успешно зарегистрирован", "Регистрация успешна", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неизвестная ошибка регистрации. Возможно отсутствует соединение с БД.", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Неизвестная ошибка регистрации. Возможно отсутствует соединение с БД.", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SignInWndBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
