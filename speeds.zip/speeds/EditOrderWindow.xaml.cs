﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace speeds
{
    public partial class EditOrderWindow : Window
    {
        public string EditMode;
        private GetOrders_Result _order;
        public EditOrderWindow(string editMode, GetOrders_Result order)
        {
            InitializeComponent();
            EditMode = editMode;
            _order = order;
            InitForm();

        }

        private void InitForm()
        {
            if (EditMode == "creating")
            {
                WindowTitle.Content = "Создание заказа";
            }
            else if (EditMode == "editing")
            {
                WindowTitle.Content = "Редактирование заказа";
                
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
